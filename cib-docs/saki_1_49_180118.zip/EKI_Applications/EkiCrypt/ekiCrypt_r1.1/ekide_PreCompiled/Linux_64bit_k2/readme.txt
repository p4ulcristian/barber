This is for 64bit linux versions using kernel 2.x
